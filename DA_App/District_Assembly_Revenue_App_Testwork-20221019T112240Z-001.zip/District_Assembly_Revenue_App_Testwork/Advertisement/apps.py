from django.apps import AppConfig


class AdvertisementConfig(AppConfig):
    name = 'Advertisement'
