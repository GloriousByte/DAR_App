from django.apps import AppConfig


class TollspaymentConfig(AppConfig):
    name = 'tollspayment'
