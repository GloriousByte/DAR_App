from django.apps import AppConfig
class OfficialpageConfig(AppConfig):
    name = 'OfficialPage'


